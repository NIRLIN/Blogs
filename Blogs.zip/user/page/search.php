<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>主页</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- page style -->
    <style>
        .my_content {
            padding-top: 18%;
            text-align: center;
            font-size: 28px;

            /*background: #f00;*/
        }

        body {

        }
    </style>
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="../css/bootstrap/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../css/font-awesome/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="../css/Ionicons/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../css/AdminLTE/AdminLTE.min.css">
    <!-- AdminLTE Skin -->
    <link rel="stylesheet" href="../css/AdminLTE/skin/skin-blue.min.css">


</head>
<body class="hold-transition skin-blue sidebar-mini" style="background-color: #9ec6d6;">
<script type="text/javascript" color="188,52,214" opacity='1' zIndex="-2" count="150"
        src="//cdn.bootcss.com/canvas-nest.js/1.0.1/canvas-nest.min.js"></script>

<?php
session_start();
if (!isset($_GET["search"])) {
    echo "<script>alert(\"非法访问,请返回\");window.location.href='index.php';" . "</script>";
}
$search = $_GET["search"];
require('../packge/dao/DaoSearchInfo.php');

$a = new DaoSearchInfo();
$argv = array();
$argv = $a->DaoSearchInfo1($search);

?>


<!--导航开始-->
<nav class="navbar navbar-default" style="background-color: #58deef">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">Blogs</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li><a href="">&nbsp;</a></li>
                <li class="active"><a href="index.php">网站首页 <span class="sr-only">(current)</span></a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="<?php if (!isset($_SESSION['name'])) {
                        echo "NoLogin.php";
                    } else {
                        echo "my_blog.php?user_name=" . $_SESSION['name'];
                    } ?>">我的博客</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="<?php if (!isset($_SESSION['name'])) {
                        echo "NoLogin.php";
                    } else {
                        echo "EditorBlog.php?user_name=" . $_SESSION['name'];
                    } ?>">编写博客</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="">&nbsp;</a></li>

            </ul>
            <form class="navbar-form navbar-left" action="search.php" method="get">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Search" id="search" name="search" value="<?php echo $search; ?>">
                </div>
                <button type="submit" class="btn btn-default">搜索</div>
            </form>
            <ul class="nav navbar-nav navbar-right">

                                <li class="dropdown" style="margin-top: -50px;"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php if (isset($_SESSION["name"])) {echo $_SESSION["name"];} else {echo "未登录";} ?><span class="caret"></span></a>

                    <ul class="dropdown-menu">
                        <li><a href="login.php">登录</a></li>
                        <li><a href="user_info.php">个人信息</a></li>

                        <li><a href="forgetpass.php">修改密码</a></li>
                        <li><a href="register.php">注册</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="../packge/controller/DestroyLogin.php">登出</a></li>
                    </ul>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<!--导航结束-->


<!-- Main content -->
<section class="content container-fluid">

    <div class="box-body">
        <table id="my_order" class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>博文</th>

            </tr>
            </thead>
            <tbody>
            <?php
            $i = 0;
            for ($i = 0; $i < count($argv); $i = $i + 1) {
                $argv1 = $argv[$i];
                if ($i % 10 == 0) {

                    ?>

                    <tr role="row" class="odd"><!--一行的开始  -->
                <?php } ?>
                <td>
                    <p style="float: left;background-color: #d69ed4"><span class="glyphicon glyphicon-leaf"></span><font
                                color="D6536A" size="5sp"><?php echo $argv1[6] ?></font></p>

                    <p><a href="<?php $herf = 'blog_info.php?blog_id=' . $argv1[0];
                        echo $herf; ?>"><font color="5E83D6" size="5sp"><?php echo '&nbsp;&nbsp;&nbsp;';
                                echo $argv1[1] ?></font></a></p>
                    <p><font color="6C27D6" size="5sp"><?php $content = $argv1[2];
                            if (iconv_strlen($content, "UTF-8") >= 100) {
                                $content = mb_substr("$content", 0, 120, 'utf-8');
                                echo " " . $content . "......";
                            } else echo " " . $content; ?></font></p>

                    <p style="float: left;"><span class="glyphicon glyphicon-user"></span><font color="A37DFF"
                                                                                                size="5sp"><?php echo $argv1[3] ?>
                            &nbsp;&nbsp;</font></p>
                    <p style="float: left;"><span class="glyphicon glyphicon-time"></span><font color="A37DFF"
                                                                                                size="5sp"><?php echo $argv1[4] ?>
                            &nbsp;&nbsp;</font></p>
                    <p style="float: left;"><span class="glyphicon glyphicon-eye-open"></span><font color="A37DFF"
                                                                                                    size="5sp"><?php echo $argv1[5] ?>
                            &nbsp;&nbsp;</font></p>

                </td>

                </tr>
                <?php
                if ($i % 10 == 9) {
                    ?>
                    <!--一行的结束  -->


                    <?php
                }
            }
            ?>
            </tbody>
            <tfoot>
            <tr>
                <th>博文</th>

            </tr>
            </tfoot>
        </table>
    </div>
    <!-- /.box-body -->

</section>
<!-- /.content -->


<!-- jQuery 3 -->
<script src="../js/jquery/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../js/bootstrap/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="../js/datatables.net/jquery.dataTables.min.js"></script>
<script src="../js/datatables.net-bs/dataTables.bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="../js/AdminLTE/adminlte.min.js"></script><!-- moment -->
<!-- <script src="../js/moment/moment.min.js"></script> -->
<!-- page script -->
<script>
    $(function () {
        $('#my_order').DataTable({
            'paging': true,
            'lengthChange': false,
            'searching': false,
            'ordering': false,
            'info': true,
            'autoWidth': false,
            'pagingType': 'full_numbers'
        })
    })
</script>

</body>
</html>