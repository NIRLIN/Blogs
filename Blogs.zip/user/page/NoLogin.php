<?php
echo "<script>alert(\"请登录！\");window.location.href='index.php';</script>";
