<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>登录</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- page style -->
    <style>

    </style>
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="../css/bootstrap/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../css/font-awesome/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="../css/Ionicons/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../css/AdminLTE/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="../css/iCheck/square/blue.css">
    <script type="text/javascript">
        function Name1(str) {
            if (str.length < 2 || str.length > 15) {
                document.getElementById("Name2").innerHTML = "用户名格式不正确，长度应大于2，小于15";
                document.all['Name2'].style.color = "#ff0000";
            } else {
                document.getElementById("Name2").innerHTML = "";
            }
        }

        function Password1(str) {
            //密码以字母开头，长度在6-18之间，只能包含字符、数字和下划线
            var pPattern = /^[a-zA-Z]\w{5,17}$/;
            //输出 true
            var rs = pPattern.test(str);
            if (!rs) {
                document.getElementById("Password2").innerHTML = "密码以字母开头，长度在6-18之间，只能包含字符、数字和下划线";
                document.all['Password2'].style.color = "#ff0000";
            } else {
                document.getElementById("Password2").innerHTML = "";
            }
        }

        function Email1(str) {
            var pPattern = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            //输出 true
            var rs = pPattern.test(str);

            if (!rs) {
                document.getElementById("Email2").innerHTML = "邮箱格式不正确";
                document.all['Email2'].style.color = "#ff0000";
            } else {

                document.getElementById("Email2").innerHTML = "";
            }
        }

        function Phone1(str1) {
            var pPattern = /^0?(13[0-9]|15[012356789]|18[0236789]|14[57])[0-9]{8}$/;
            //输出 true
            var rs = pPattern.test(str1);

            if (!rs) {
                document.getElementById("Phone2").innerHTML = "手机格式不正确";
                document.all['Phone2'].style.color = "#ff0000";

            } else {
                document.getElementById("Phone2").innerHTML = "";
                var xmlhttp;
                $.ajax({
                    type: "get",
                    url: "../packge/utils/getCode.php?phone=" + str1,
                    data: {data: 1},
                    dataType: 'text',
                    success: function (data) {
                        console.log(data.toString());
                        sessionStorage.setItem('code', data.toString());
                    }
                });
            }
        }

        function Real_name1(str) {
            var pPattern = /^[\u4e00-\u9fa5]{2,4}$/;
            //输出 true
            var rs = pPattern.test(str);

            if (!rs) {
                document.getElementById("Real_name2").innerHTML = "姓名有误";
                document.all['Real_name2'].style.color = "#ff0000";
            } else {

                document.getElementById("Real_name2").innerHTML = "";
            }
        }


    </script>
</head>
<body class="hold-transition login-page">
<?php session_start(); ?>
<div class="login-box">
    <div class="login-logo">
        <a href="login.php"><b>个人博客系统</b></a>
    </div>
    <!-- /.login-logo -->
    <div class="login-box-body">
        <p class="login-box-msg">用户注册</p>

        <form action="../packge/controller/UserRegister.php" method="post" id="userregister" name="userregister">
            <div class="form-group has-feedback">
                <input type="text" class="form-control" placeholder="Name" id="Name" name="Name"
                       onBlur="Name1(this.value)">
                <span id="Name2"></span>
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="password" class="form-control" placeholder="Password" id="Password" name="Password"
                       onBlur="Password1(this.value)">
                <span id="Password2"></span>
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="email" class="form-control" placeholder="Email" id="Email" name="Email"
                       onBlur="Email1(this.value)">
                <span id="Email2"></span>
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            </div>


            <div class="form-group has-feedback">
                <input type="text" class="form-control" placeholder="Real_name" id="Real_name" name="Real_name"
                       onBlur="Real_name1(this.value)">
                <span id="Real_name2"></span>
                <span class="glyphicon glyphicon-tower form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="text" class="form-control" name="Birthday" id="Birthday" placeholder="Birthday">

                <span class="glyphicon glyphicon-btc form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="text" class="form-control" placeholder="Phone" id="Phone" name="Phone"
                       onBlur="Phone1(this.value)" />
                <span id="Phone2"></span>

                <span class="glyphicon glyphicon-earphone form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="text" class="form-control" placeholder="短信验证码" id="code" name="code"
                        />
                <span id="code2"></span>

                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            </div>


            <div class="row">
                <!-- /.col -->
                <div class="col-xs-4">
                    <input type="button" class="btn btn-primary btn-block btn-flat" onclick="f()" value="注册">
                </div>
                <!-- /.col -->
            </div>
        </form>


        <br>
    </div>
    <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="../js/jquery/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../js/bootstrap/bootstrap.min.js"></script>
<!-- bootstrap datepicker -->
<script src="../js/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script src="../js/bootstrap-datepicker/bootstrap-datepicker.zh-CN.min.js"></script>
<!-- AdminLTE App -->
<script src="../js/AdminLTE/adminlte.min.js"></script>
<!-- page script -->
<script>
    $('#Birthday').datepicker({
        language: 'zh-CN',
        todayHighlight: true,
        format: 'yyyy-mm-dd',
        autoclose: true
    });

    function f() {
        var Name2 = document.getElementById("Name2");
        var Password2 = document.getElementById("Password2");
        var Email2 = document.getElementById("Email2");
        var Phone2 = document.getElementById("Phone2");
        var Real_name2 = document.getElementById("Real_name2");

        if (Name2.innerHTML.length > 0 || Password2.innerHTML.length > 0 || Email2.innerHTML.length > 0 || Phone2.innerHTML.length > 0 || Real_name2.innerHTML.length > 0) {
            alert("信息不正确！请修改！");
            return
        }
        var Name = document.getElementById("Name");
        var Password = document.getElementById("Password");
        var Email = document.getElementById("Email");
        var Phone = document.getElementById("Phone");
        var Real_name = document.getElementById("Real_name");
        var Birthday = document.getElementById("Birthday");

        if (Name.value === "" || Password.value === "" || Email.value === "" || Phone.value === "" || Real_name.value === "" || Birthday.value === "") {
            alert("信息不可为空！请填写！");
            return
        }
        var code=  sessionStorage.getItem('code');
        var code1=  document.getElementById("code");
        if (code!==code1.value){
            alert(code.value+"验证码不正确！"+code1.value  );

            return;
        }

        $("#userregister").submit();
    }



</script>


<script type="text/javascript" color="188,52,214" opacity='1' zIndex="-2" count="150"
        src="//cdn.bootcss.com/canvas-nest.js/1.0.1/canvas-nest.min.js"></script>

</body>
</html>
