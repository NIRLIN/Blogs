<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>主页</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- page style -->
    <style>
        .my_content {
            padding-top: 18%;
            text-align: center;
            font-size: 28px;

            /*background: #f00;*/
        }

        body {

        }
    </style>
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="../css/bootstrap/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../css/font-awesome/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="../css/Ionicons/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../css/AdminLTE/AdminLTE.min.css">
    <!-- AdminLTE Skin -->
    <link rel="stylesheet" href="../css/AdminLTE/skin/skin-blue.min.css">


</head>
<body class="hold-transition skin-blue sidebar-mini" style="background-color: #9ec6d6;">
<script type="text/javascript" color="188,52,214" opacity='1' zIndex="-2" count="150"
        src="//cdn.bootcss.com/canvas-nest.js/1.0.1/canvas-nest.min.js"></script>

<?php
session_start();
require('../packge/dao/DaoFindAllBlog.php');

$a = new DaoFindAllBlog();
$argv = array();
$argv = $a->daoFindBlog();
$search="";
if (isset($_GET["search"])) {
    $search = $_GET["search"];
}
if (!isset($_SESSION["name"])) {
    echo "<script>alert(\"非法访问！请登录\");window.location.href='../page/index.php';</script>";
}

require('../packge/dao/DaoFindUserInfo.php');

$info = new DaoFindUserInfo();
$info1 = array();
$info1 = $info->DaoFindUserInfo1($_SESSION["name"]);

?>


<!--导航开始-->
<nav class="navbar navbar-default" style="background-color: #58deef">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">Blogs</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li><a href="">&nbsp;</a></li>
                <li class="active"><a href="index.php">网站首页 <span class="sr-only">(current)</span></a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="<?php if (!isset($_SESSION['name'])) {
                        echo "NoLogin.php";
                    } else {
                        echo "my_blog.php?user_name=" . $_SESSION['name'];
                    } ?>">我的博客</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="<?php if (!isset($_SESSION['name'])) {
                        echo "NoLogin.php";
                    } else {
                        echo "EditorBlog.php?user_name=" . $_SESSION['name'];
                    } ?>">编写博客</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="">&nbsp;</a></li>
                <li><a href="">&nbsp;</a></li>

            </ul>
            <form class="navbar-form navbar-left" action="search.php" method="get">
                <div class="form-group">
                    <input style="width: 80%;"style="width: 30%;" type="text" class="form-control" placeholder="Search" id="search" name="search" value="<?php echo $search; ?>">
                </div>
                <button type="submit" class="btn btn-default">搜索</div>
            </form>
            <ul class="nav navbar-nav navbar-right">

                <li class="dropdown" style="margin-top: -50px;"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php if (isset($_SESSION["name"])) {echo $_SESSION["name"];} else {echo "未登录";} ?><span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="login.php">登录</a></li>
                        <li><a href="user_info.php">个人信息</a></li>
                        <li><a href="user_info.php">个人信息</a></li>

                        <li><a href="forgetpass.php">修改密码</a></li>
                        <li><a href="register.php">注册</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="../packge/controller/DestroyLogin.php">登出</a></li>
                    </ul>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<!--导航结束-->


<!-- Main content -->
<section class="content container-fluid" style="width: 35%;margin-top: 6%;">
    <!-- Horizontal Form -->
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">个人信息</h3>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form class="form-horizontal" role="form" method="post" action="../packge/controller/user_info_change.php   ">
            <div class="box-body">
                <div class="form-group">
                    <label for="isbn" class="col-sm-2 control-label my-label">用户id</label>
                    <div class="col-sm-10 my-input">
                        <input style="width: 80%;" type="text"  class="form-control" name="user_id" id="user_id" value="<?php echo $info1[0]?>" readonly >
                    </div>
                    <br>
                    <label for="title" class="col-sm-2 control-label my-label">登录名</label>
                    <div class="col-sm-10 my-input">
                        <input style="width: 80%;" type="text" class="form-control" name="login_name" id="login_name" value="<?php echo $info1[1]?>" >
                    </div>
                    <br>

                    <label for="author" class="col-sm-2 control-label my-label">用户邮箱</label>
                    <div class="col-sm-10 my-input">
                        <input style="width: 80%;" type="text" class="form-control" name="user_email" id="user_email" value="<?php echo $info1[3]?>" >
                    </div>
                    <br>

                    <label for="price" class="col-sm-2 control-label my-label">用户手机</label>
                    <div class="col-sm-10 my-input">
                        <input style="width: 80%;" type="text" class="form-control" name="user_phone" id="user_phone" value="<?php echo $info1[4]?>" >
                    </div>
                    <br>
                    <label for="price" class="col-sm-2 control-label my-label">真实姓名</label>
                    <div class="col-sm-10 my-input">
                        <input style="width: 80%;" type="text" class="form-control" name="user_real_name" id="user_real_name" value="<?php echo $info1[5]?>" >
                    </div>
                    <br>

                    <label for="pages" class="col-sm-2 control-label my-label">用户生日</label>
                    <div class="col-sm-10 my-input">
                        <input style="width: 80%;" type="text" class="form-control" name="birthday" id="birthday" value="<?php echo $info1[7]?>" >
                    </div>
                    <br>


                </div>

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary pull-right">修改</button>
                </div>

            </div>
            <!-- /.box-body -->
            <div class="box-footer">
            </div>
            <!-- /.box-footer -->
        </form>
    </div>
</section>
<!-- /.content -->


<!-- jQuery 3 -->
<script src="../js/jquery/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../js/bootstrap/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="../js/datatables.net/jquery.dataTables.min.js"></script>
<script src="../js/datatables.net-bs/dataTables.bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="../js/AdminLTE/adminlte.min.js"></script><!-- moment -->
<!-- <script src="../js/moment/moment.min.js"></script> -->
<!-- page script -->
<script>
    $('#birthday').datepicker({
        language: 'zh-CN',
        todayHighlight: true,
        format: 'yyyy-mm-dd',
        autoclose: true
    });
</script>
<script>

    $(function () {
        $('#my_order').DataTable({
            'paging': true,
            'lengthChange': false,
            'searching': false,
            'ordering': false,
            'info': true,
            'autoWidth': false,
            'pagingType': 'full_numbers'
        })

    })
</script>

</body>
</html>