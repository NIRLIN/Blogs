<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>登录</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- page style -->
    <style>

    </style>
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="../css/bootstrap/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../css/font-awesome/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="../css/Ionicons/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../css/AdminLTE/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="../css/iCheck/square/blue.css">
    <!-- Google Font -->
    <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic"> -->
</head>
<body class="hold-transition login-page">
<script type="text/javascript" color="188,52,214" opacity='1' zIndex="-2" count="150"
        src="//cdn.bootcss.com/canvas-nest.js/1.0.1/canvas-nest.min.js"></script>

<div class="login-box">
    <div class="login-logo">
        <a href="login.php"><b>个人博客系统</b></a>
    </div>
    <!-- /.login-logo -->
    <div class="login-box-body">
        <p class="login-box-msg">修改密码</p>
        <form action="../packge/controller/ChangePassword.php" method="post" id="userlogin" name="userlogin">
            <div class="form-group has-feedback">
                <input type="text" class="form-control" placeholder="Name" id="name" name="name">
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="password" class="form-control" placeholder="Password" id="password" name="password">
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="password" class="form-control" placeholder="NewPassword" id="newPassword"
                       name="newPassword">
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="password" class="form-control" placeholder="AgainNewPassword" id="anewPassword"
                       name="anewPassword">
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <div class="row">
                <!-- /.col -->
                <div class="col-xs-4">
                    <input type="button" class="btn btn-primary btn-block btn-flat" onclick="f()" value="修改">
                </div>
                <!-- /.col -->
            </div>
        </form>
        <script>
            function f() {
                var name = document.getElementById("name");
                var password = document.getElementById("password");
                var newPassword = document.getElementById("newPassword");
                var anewPassword = document.getElementById("anewPassword");
                if (name.value == "" || password.value == "" || newPassword.value == "" || anewPassword.value == "") {
                    alert("账号或密码不能为空！");
                    return
                }

                if (newPassword.value != anewPassword.value) {
                    alert("两次密码不一致！");
                    return
                }
                if (password.value == anewPassword.value) {
                    alert("新密码和旧密码不可相同！");
                    return
                }
                $("#userlogin").submit();
            }


        </script>
        <!-- /.social-auth-links -->
        <a href="#">忘记密码？</a><br>
    </div>
    <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="../js/jquery/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../js/bootstrap/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="../js/iCheck/icheck.min.js"></script>
<!-- page script -->
<script>
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%' // optional
        });
    });
</script>
</body>
</html>
