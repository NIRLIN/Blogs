<?php


class DaoUseIdFindName
{
    public function daoUseIdFindNamel($user_id){
        $sql="select user_id from tb_user where user_id=".$user_id;
        $link=mysqli_connect('localhost','root','123456','blog','3306');
        mysqli_set_charset($link,'utf-8');
        $result=mysqli_query($link,$sql);
        $argv=mysqli_fetch_all($result);
        mysqli_free_result($result);
        mysqli_close($link);
        return $argv;
    }

}