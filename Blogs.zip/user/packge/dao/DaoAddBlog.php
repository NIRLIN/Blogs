<?php


class DaoAddBlog
{
    public function DaoAddBlog1( $sql){
        $link=mysqli_connect('localhost','root','123456','blog','3306');
        mysqli_set_charset($link,'utf-8');
        $result=mysqli_query($link,$sql);
        if (!$result) {
            printf("Error: %s\n", mysqli_error($link));
            exit();
        }
        mysqli_close($link);
        return $result;
    }
}