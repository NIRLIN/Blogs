<?php


class DaoUser_login
{
    public function dao_user_login($name,$password){
        $sql="select * from tb_user where user_name=\"".$name."\" and user_password=".$password;
        $link=mysqli_connect('localhost','root','123456','blog','3306');
        mysqli_set_charset($link,'utf-8');
        $result=mysqli_query($link,$sql);
        if (!$result) {
            printf("Error: %s\n", mysqli_error($link));
            exit();
        }
        $rs=mysqli_num_rows($result);


        mysqli_close($link);
        return $rs;
    }



}