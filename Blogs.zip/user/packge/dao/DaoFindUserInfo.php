<?php


class DaoFindUserInfo
{
    public function DaoFindUserInfo1($user_name)
    {
        $link=mysqli_connect('localhost','root','123456','blog','3306');
        $sql="SELECT * FROM tb_user WHERE user_name='".$user_name."'";

        $result=mysqli_query($link,$sql);
        if (!$result) {
            printf("Error: %s\n", mysqli_error($link));
            exit();
        }
        $argv=mysqli_fetch_all($result);
        $argv=$argv[0];
        mysqli_close($link);
        return $argv;

    }

}