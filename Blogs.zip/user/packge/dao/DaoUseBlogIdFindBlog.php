<?php


class DaoUseBlogIdFindBlog
{
   public function daoUserIdFindBlog($blog_id){
       $argv=array();

       $sql="update tb_blog set blog_browse_count=blog_browse_count+1 where blog_id=".$blog_id;//增加阅读数量
       $link=mysqli_connect('localhost','root','123456','blog','3306');
       mysqli_set_charset($link,'utf-8');
       mysqli_query($link,$sql);


       $sql="select * from tb_blog where blog_id=".$blog_id;//查找博文
       $link=mysqli_connect('localhost','root','123456','blog','3306');
       mysqli_set_charset($link,'utf-8');
       $result=mysqli_query($link,$sql);
       $argv=mysqli_fetch_all($result);


       mysqli_free_result($result);
       mysqli_close($link);
       return $argv;
   }

}