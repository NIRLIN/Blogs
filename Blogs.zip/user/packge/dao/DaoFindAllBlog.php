<?php


class DaoFindAllBlog
{
    public function daoFindBlog(){
        $argv=array();
        $sql="select * from tb_blog order by blog_publish_date desc ";
        $link=mysqli_connect('localhost','root','123456','blog','3306');
        mysqli_set_charset($link,'utf-8');
        $result=mysqli_query($link,$sql);
        $argv=mysqli_fetch_all($result);
        mysqli_free_result($result);
        mysqli_close($link);
        return $argv;

    }

}