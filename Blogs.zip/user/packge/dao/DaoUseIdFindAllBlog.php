<?php


class DaoUseIdFindAllBlog
{
    public function daoFindBlog($user_name){
        $argv=array();
        $sql="select * from tb_blog where user_name=\"".$user_name."\"";
        $link=mysqli_connect('localhost','root','123456','blog','3306');
        mysqli_set_charset($link,'utf-8');
        $result=mysqli_query($link,$sql);
        $argv=mysqli_fetch_all($result);
        mysqli_free_result($result);
        mysqli_close($link);
        return $argv;

    }

}