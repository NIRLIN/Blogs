<?php


class DaoSearchInfo
{
    public function DaoSearchInfo1($search){
        $link=mysqli_connect('localhost','root','123456','blog','3306');
        $sql="SELECT * FROM tb_blog WHERE blog_title LIKE '%".$search."%' OR blog_content LIKE '%".$search."%'  OR blog_sort LIKE '%".$search."%' OR blog_publish_date LIKE '%".$search."%'  OR user_name LIKE '".$search."%'";

        $result=mysqli_query($link,$sql);
        if (!$result) {
            printf("Error: %s\n", mysqli_error($link));
            exit();
        }
        $argv=mysqli_fetch_all($result);

        mysqli_close($link);
        return $argv;
    }
}