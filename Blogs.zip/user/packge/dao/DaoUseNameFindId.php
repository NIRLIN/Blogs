<?php


class DaoUseNameFindId
{
    public function daoUseNameFindIdl($user_name){
        $sql="select user_id from tb_user where user_name=\"".$user_name."\"";
        $link=mysqli_connect('localhost','root','123456','blog','3306');
        mysqli_set_charset($link,'utf-8');
        $result=mysqli_query($link,$sql);
        if (!$result) {
            printf("Error: %s\n", mysqli_error($link));
            exit();
        }
        $argv=mysqli_fetch_all($result);
        mysqli_free_result($result);
        mysqli_close($link);
        return $argv;
    }

}