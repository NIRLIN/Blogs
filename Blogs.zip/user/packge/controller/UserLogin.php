<?php
if (isset($_POST["name"])&&isset($_POST["password"])){
    $name=$_POST["name"];
    $password=$_POST["password"];
    require ('../dao/DaoUser_login.php');
    $user_login=new DaoUser_login();
    $rsnum=$user_login->dao_user_login($name,$password);
    if ($rsnum==1){
        session_start();
        $_SESSION['name']=$name;
        echo $_SESSION['name'];
        echo "<script>window.location.href='../../page/index.php';</script>";
    }

}else{
    echo "<script>alert(\"非法访问！\");window.location.href='../../page/index.php';</script>";
}

