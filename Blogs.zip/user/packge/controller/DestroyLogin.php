<?php
session_start();
unset( $_SESSION['name']);
echo "<script>alert(\"退出！\");window.location.href='../../page/index.php';</script>";

