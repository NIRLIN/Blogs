<?php
if (isset($_GET["blog_id"])){
    $blog_id=$_GET["blog_id"];
    $sql="delete from tb_blog where blog_id=".$blog_id;
    $link=mysqli_connect('localhost','root','123456','blog','3306');
    mysqli_set_charset($link,'utf-8');
    $result=mysqli_query($link,$sql);
    if (!$result) {
        printf("Error: %s\n", mysqli_error($link));
        exit();
    }
    mysqli_close($link);
    if ($result){
        session_start();
        $href="../../page/my_blog.php?user_name=".$_SESSION['name'];
        echo $href;
        echo "<script>alert(\"删除成功！\");window.location.href='".$href."';</script>";
    }
}else{
    echo "<script>alert(\"非法访问！\");window.location.href='../../page/index.php';</script>";
}