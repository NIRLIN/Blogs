<?php
$user_id= $_POST["user_id"];
$user_name= $_POST["login_name"];
$user_email= $_POST["user_email"];
$user_phone= $_POST["user_phone"];
$user_real_name= $_POST["user_real_name"];
$user_birthday= $_POST["birthday"];
$link=mysqli_connect('localhost','root','123456','blog','3306');

$sql="UPDATE tb_user SET user_name = '".$user_name."' , user_email = '".$user_email."' , user_phone = '".$user_phone."' , user_real_name = '".$user_real_name."' , user_birthday = '".$user_birthday."'   WHERE user_id = '".$user_id."'";

$result=mysqli_query($link,$sql);
if (!$result) {
    printf("Error: %s\n", mysqli_error($link));
    exit();
}

if ($result){
    echo "<script>alert(\"修改成功！\");window.location.href='../../page/user_info.php';</script>";
}
else{
    echo "<script>alert(\"修改失败！\");window.location.href='../../page/user_info.php';</script>";
}

