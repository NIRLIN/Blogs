<?php
if (isset($_POST["Name"])&&isset($_POST["Password"])&&isset($_POST["Email"])&&isset($_POST["Phone"])&&isset($_POST["Real_name"])&&isset($_POST["Real_name"])&&isset($_POST["Birthday"])){
    $Name=$_POST["Name"];
    $Password=$_POST["Password"];
    $Email=$_POST["Email"];
    $Phone=$_POST["Phone"];

    $Real_name=$_POST["Real_name"];
    $Birthday=$_POST["Birthday"];
    $date=date('Y-m-d H:i:s');
    $data="\"".$Name."\",\"".$Password."\",\"".$Email."\",\"".$Phone."\",\"".$Real_name."\",\"".$date."\",\"".$Birthday."\"";
    $sql="INSERT INTO tb_user (user_name,user_password,user_email,user_phone,user_real_name,user_login_date,user_birthday) VALUES (".$data.")";


    $link=mysqli_connect('localhost','root','123456','blog','3306');
    mysqli_set_charset($link,'utf-8');

    $result=mysqli_query($link,$sql);
    if (!$result) {
        printf("Error: %s\n", mysqli_error($link));
        exit();
    }

    mysqli_close($link);
    if ($result){
        echo "<script>alert(\"注册成功！\");window.location.href='../../page/login.php';</script>";
    }
}else{
    echo "<script>alert(\"非法访问！\");window.location.href='../../page/register.php';</script>";
}


?>
