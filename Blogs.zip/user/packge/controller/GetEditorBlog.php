<?php
$blog_title=$_POST["title"];
$blog_content=$_POST["content"];
session_start();
$user_name=$_SESSION["name"];
$blog_publish_date=date('Y-m-d H:i:s');
$blog_sort=$_POST["select"];
$sql="insert into tb_blog(blog_title,blog_content,user_name,blog_publish_date,blog_sort) VALUES ('$blog_title','$blog_content','$user_name','$blog_publish_date','$blog_sort')";
require ('../dao/DaoAddBlog.php');
$a=new DaoAddBlog();
$b=$a->daoAddBlog1($sql);
if ($b){
    echo "<script>alert(\"保存成功！\");window.location.href='../../page/index.php';</script>";
}else{
    echo "<script>alert(\"保存失败！\");window.location.href='../../page/index.php';</script>";
}








