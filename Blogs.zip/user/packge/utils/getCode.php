<?php
if (isset($_GET["phone"])){
    $phone=$_GET["phone"];
    $code= rand(pow(10,(6-1)), pow(10,6)-1);
    include 'AliSms.php';
    $ali=new AliSms();
    $ali->Alisms1($phone,$code);
    echo $code;
}else{
    echo  "error";
}

