<?php
include  '../../sdk/vendor/autoload.php';
use AlibabaCloud\Client\AlibabaCloud;
use AlibabaCloud\Client\Exception\ClientException;
use AlibabaCloud\Client\Exception\ServerException;


class AliSms
{
    public function Alisms1($phone,$code){



// Download：https://github.com/aliyun/openapi-sdk-php
// Usage：https://github.com/aliyun/openapi-sdk-php/blob/master/README.md

        try {
            AlibabaCloud::accessKeyClient('LTAI4FmratVc3aAFu61b3CP7', '5rvArtzS1q3Fxmu8SzpDzjNz5xXuhh')
                ->regionId('cn-hangzhou')
                ->asDefaultClient();
        } catch (ClientException $e) {
            echo $e;
        }

        try {
            $result = AlibabaCloud::rpc()
                ->product('Dysmsapi')
                // ->scheme('https') // https | http
                ->version('2017-05-25')
                ->action('SendSms')
                ->method('POST')
                ->host('dysmsapi.aliyuncs.com')
                ->options([
                    'query' => [
                        'RegionId' => "cn-hangzhou",
                        'PhoneNumbers' => $phone,
                        'SignName' => "学生信息管理",
                        'TemplateCode' => "SMS_179225552",
                        'TemplateParam' => "{\"code\":\"".$code."\"}",
                    ],
                ])
                ->request();
//            print_r($result->toArray());
        } catch (ClientException $e) {
            echo $e->getErrorMessage() . PHP_EOL;
        } catch (ServerException $e) {
            echo $e->getErrorMessage() . PHP_EOL;
        }

    }

}
