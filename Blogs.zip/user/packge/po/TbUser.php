<?php


class TbUser
{
    private int $userId;
    private String $userName;
    private String $userPassword;
    private String $userEmail;
    private String $userPhone;
    private String $userRealName;
    private \Cassandra\Date $userLoginDate;
    private String $userAge;
    private \Cassandra\Date $userBirthday;

    /**
     * @return int
     */
    public function getUserId(): int
    {
        return $this->userId;
    }

    /**
     * @param int $userId
     */
    public function setUserId(int $userId): void
    {
        $this->userId = $userId;
    }

    /**
     * @return String
     */
    public function getUserName(): String
    {
        return $this->userName;
    }

    /**
     * @param String $userName
     */
    public function setUserName(String $userName): void
    {
        $this->userName = $userName;
    }

    /**
     * @return String
     */
    public function getUserPassword(): String
    {
        return $this->userPassword;
    }

    /**
     * @param String $userPassword
     */
    public function setUserPassword(String $userPassword): void
    {
        $this->userPassword = $userPassword;
    }

    /**
     * @return String
     */
    public function getUserEmail(): String
    {
        return $this->userEmail;
    }

    /**
     * @param String $userEmail
     */
    public function setUserEmail(String $userEmail): void
    {
        $this->userEmail = $userEmail;
    }

    /**
     * @return String
     */
    public function getUserPhone(): String
    {
        return $this->userPhone;
    }

    /**
     * @param String $userPhone
     */
    public function setUserPhone(String $userPhone): void
    {
        $this->userPhone = $userPhone;
    }

    /**
     * @return String
     */
    public function getUserRealName(): String
    {
        return $this->userRealName;
    }

    /**
     * @param String $userRealName
     */
    public function setUserRealName(String $userRealName): void
    {
        $this->userRealName = $userRealName;
    }

    /**
     * @return \Cassandra\Date
     */
    public function getUserLoginDate(): \Cassandra\Date
    {
        return $this->userLoginDate;
    }

    /**
     * @param \Cassandra\Date $userLoginDate
     */
    public function setUserLoginDate(\Cassandra\Date $userLoginDate): void
    {
        $this->userLoginDate = $userLoginDate;
    }

    /**
     * @return String
     */
    public function getUserAge(): String
    {
        return $this->userAge;
    }

    /**
     * @param String $userAge
     */
    public function setUserAge(String $userAge): void
    {
        $this->userAge = $userAge;
    }

    /**
     * @return \Cassandra\Date
     */
    public function getUserBirthday(): \Cassandra\Date
    {
        return $this->userBirthday;
    }

    /**
     * @param \Cassandra\Date $userBirthday
     */
    public function setUserBirthday(\Cassandra\Date $userBirthday): void
    {
        $this->userBirthday = $userBirthday;
    }

}