<?php


class TbBlog
{
    private int $blogId;
    private String $blogTitle;
    private String $blogContent;
    private int $userId;
    private \Cassandra\Date $blogPublishDate;
    private int $blogBrowseCount;
    private String $blogSort;

    /**
     * @return int
     */
    public function getBlogId(): int
    {
        return $this->blogId;
    }

    /**
     * @param int $blogId
     */
    public function setBlogId(int $blogId): void
    {
        $this->blogId = $blogId;
    }

    /**
     * @return String
     */
    public function getBlogTitle(): String
    {
        return $this->blogTitle;
    }

    /**
     * @param String $blogTitle
     */
    public function setBlogTitle(String $blogTitle): void
    {
        $this->blogTitle = $blogTitle;
    }

    /**
     * @return String
     */
    public function getBlogContent(): String
    {
        return $this->blogContent;
    }

    /**
     * @param String $blogContent
     */
    public function setBlogContent(String $blogContent): void
    {
        $this->blogContent = $blogContent;
    }

    /**
     * @return int
     */
    public function getUserId(): int
    {
        return $this->userId;
    }

    /**
     * @param int $userId
     */
    public function setUserId(int $userId): void
    {
        $this->userId = $userId;
    }

    /**
     * @return \Cassandra\Date
     */
    public function getBlogPublishDate(): \Cassandra\Date
    {
        return $this->blogPublishDate;
    }

    /**
     * @param \Cassandra\Date $blogPublishDate
     */
    public function setBlogPublishDate(\Cassandra\Date $blogPublishDate): void
    {
        $this->blogPublishDate = $blogPublishDate;
    }

    /**
     * @return int
     */
    public function getBlogBrowseCount(): int
    {
        return $this->blogBrowseCount;
    }

    /**
     * @param int $blogBrowseCount
     */
    public function setBlogBrowseCount(int $blogBrowseCount): void
    {
        $this->blogBrowseCount = $blogBrowseCount;
    }

    /**
     * @return String
     */
    public function getBlogSort(): String
    {
        return $this->blogSort;
    }

    /**
     * @param String $blogSort
     */
    public function setBlogSort(String $blogSort): void
    {
        $this->blogSort = $blogSort;
    }

}